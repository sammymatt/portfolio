---
title: SnippetCLI
date: 2023-12-21 17:13:00 -500
categories: [CLI, C#]
tags: [CLI, C#]
---

To visit the GitHub repo, [click here](https://github.com/sammymatt).

To run the command, use `snippet --option value`.

```powershell
$ example-command --option value
$ another-command -f file.txt
```
