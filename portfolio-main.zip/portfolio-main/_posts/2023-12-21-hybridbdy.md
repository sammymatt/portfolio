---
title: HybridBDY
date: 2023-12-21 17:13:00 -500
categories: [C#, TypeScript, Angular, APIs]
tags: [C#, TypeScript, Angular, APIs]
---

To visit the GitHub repo, [click here](https://github.com/sammymatt).

## C# Backend
- controllers
- services
- dtos
- mapping

## Angular Frontend
- dashboard showing stats
- goals page, e.g. 3 cycles a week
- integration with python machine learning - which you can view [here]().