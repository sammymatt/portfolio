---
# the default layout is 'page'
icon: fa fa-code
order: 1
---

## CFC
### *Software Developer*
#### _July 2022 - Present_

- C#, Angular, Microsoft SQL, Azure
- Working on CFCs internal insurance software.

## MRI Software
### *Software Engineer*
#### _2019 - 2022_

- C#, JavaScript, Oracle PL/SQL
- Graduate role, where I spent the first year primarily performing bug fixes and issue resolving.
- A dramatic increase in my debugging and problem solving skills. 
- Revived and implemented an integration project connecting sales and lettings product with the property management product I mainly worked on. I met the deadline and demoed the entire workflow to directors and managers. This demo was then also used for sales to learn the workflow.
- A mentor to graduates and got any new joiners up to speed.
- For my final 6 months, I was in a small team working on another integration project, where we successfully delivered new functionality multiple times, with tight deadlines.

## CGI
### *Technical Consultant - Placement Year*
#### _2017 - 2018_

- Spent a year at CGI working on a project building and maintaining the software deployed on the Airbus ships which interacts with the [Skynet](https://www.airbus.com/en/products-services/defence/milsatcom/skynet-5) satellite.
- Moved around teams frequently, gaining exposure to Java, networking, window servers, linux, bash scripting, batch files, testing and more.
- Offered to return for a graduate role. 
